# 3DS Extended Homebrew Starter Pack

**This is deprecated - get your up to date homebrew software fix elsewhere.**

This is my personal, extended version of Smealums 3DS homebrew starter pack. It's built upon Smealums original homebrew starter pack available from [here](http://smealum.github.io/3ds/), and contains these softwares:
* Gridlauncher by mashers (instead of regular HB launcher)
* MenuHax Manager by Yellows8
* HANS by smealum
* CHMM2 by Rinnegatamante
* ftpd by mtheall
* mGBA by endrift
* prBoom by elhobbs
* Playcoin Setter by MrCheeze
* FBI by SteveIce10
* svdt by meladroit
* CTRXplorer by d0k3
* Decrypt9WIP by Archshift & d0k3
* EmuNAND9 by d0k3
* GodMode9 by d0k3
* BrahmaLoader by patois, delebile & d0k3 (handles ARM9 payloads)
* Luma3DS CFW by AuroraWright & reisyukaku
* MiniPasta by zoogie
* TinyFormat by javiMaD
* PlaiSysUpdater by Plailect
* Various installers and tools by smealum
