namespace PKHeX.Core.Searching
{
    public enum CloneDetectionMethod
    {
        None,
        HashDetails,
        HashPID,
    }
}