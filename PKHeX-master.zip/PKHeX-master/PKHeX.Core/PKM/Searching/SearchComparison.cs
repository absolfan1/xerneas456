namespace PKHeX.Core.Searching
{
    public enum SearchComparison
    {
        None,
        Equals,
        GreaterThanEquals,
        LessThanEquals,
    }
}