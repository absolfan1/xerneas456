namespace PKHeX.Core
{
    public enum PokeListType : byte
    {
        Single = 1,
        Party = 6,
        Stored = 20,
        StoredJP = 30,
    }
}