﻿namespace PKHeX.Core
{
    public enum FrameType
    {
        None,
        MethodH,
        MethodJ,
        MethodK,
    }
}
