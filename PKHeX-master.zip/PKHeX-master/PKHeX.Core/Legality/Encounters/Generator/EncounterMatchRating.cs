namespace PKHeX.Core
{
    public enum EncounterMatchRating
    {
        None,
        Match,
        Deferred,
    }
}