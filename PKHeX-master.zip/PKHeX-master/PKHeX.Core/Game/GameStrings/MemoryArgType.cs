﻿namespace PKHeX.Core
{
    public enum MemoryArgType
    {
        None,
        GeneralLocation,
        SpecificLocation,
        Species,
        Move,
        Item,
    }
}