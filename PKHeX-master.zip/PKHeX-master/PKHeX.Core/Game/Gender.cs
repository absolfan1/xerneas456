﻿namespace PKHeX.Core
{
    public enum Gender : byte
    {
        Male = 0,
        Female = 1,

        Genderless = 2,
        Random = Genderless,
    }
}
