﻿namespace PKHeX.Core
{
    internal enum ModifyResult
    {
        None,
        Invalid,
        Error,
        Filtered,
        Modified,
    }
}
