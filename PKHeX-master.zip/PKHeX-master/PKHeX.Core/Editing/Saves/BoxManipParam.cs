﻿namespace PKHeX.Core
{
    public struct BoxManipParam
    {
        public int Start { get; set; }
        public int Stop { get; set; }
        public bool Reverse { get; set; }
    }
}