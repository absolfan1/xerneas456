namespace PKHeX.Core
{
    public enum SlotTouchType
    {
        None,
        Get,
        Set,
        Delete,
        Swap,
    }
}