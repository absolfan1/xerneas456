#pragma once
#include "common.h"

void uiExitLoop(void);

bool uiUpdate(void);
